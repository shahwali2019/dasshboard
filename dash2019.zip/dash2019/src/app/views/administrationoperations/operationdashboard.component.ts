import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Contact } from '../contact.component';

import _ from 'lodash';

@Component({
  templateUrl: './operationdashboard.component.html'
})
export class OperationdashboardComponent {


}
