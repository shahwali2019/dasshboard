import { Component } from '@angular/core';

@Component({
  templateUrl: 'departments.component.html'
})
export class DepartmentsComponent {

  constructor() { }




}
