import { Component } from '@angular/core';

@Component({
  templateUrl: 'drugs.component.html'
})
export class DrugsComponent {


  constructor() {

  }


}
