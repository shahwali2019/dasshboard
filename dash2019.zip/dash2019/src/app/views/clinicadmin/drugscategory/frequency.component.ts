import { Component } from '@angular/core';

@Component({
  templateUrl: 'frequency.component.html'
})
export class FrequencyComponent {

  constructor() { }




}
