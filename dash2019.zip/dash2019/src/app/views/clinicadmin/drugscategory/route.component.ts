import { Component } from '@angular/core';

@Component({
  templateUrl: 'route.component.html'
})
export class RouteComponent {

  constructor() { }

}
