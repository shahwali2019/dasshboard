import { Component } from '@angular/core';

@Component({
  templateUrl: 'locations.component.html'
})
export class LocationsComponent {


  constructor() {

  }


}
