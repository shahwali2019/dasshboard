import { Component } from '@angular/core';

@Component({
  templateUrl: 'cardiologymasters.component.html'
})
export class CardiologymastersComponent {

  constructor() { }




}
