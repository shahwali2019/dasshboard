import { Component } from '@angular/core';

@Component({
  templateUrl: 'gastroentrologymasters.component.html'
})
export class GastroentrologymastersComponent {

  constructor() { }

}
