import { Component } from '@angular/core';

@Component({
  templateUrl: 'ophthalmologymasters.component.html'
})
export class OphthalmologymastersComponent {


  constructor() {

  }


}
