import { Component } from '@angular/core';

@Component({
  templateUrl: 'radiologymasters.component.html'
})
export class RadiologymastersComponent {


  constructor() {

  }


}
