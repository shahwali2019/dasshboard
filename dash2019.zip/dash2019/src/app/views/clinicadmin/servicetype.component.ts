import { Component } from '@angular/core';

@Component({
  templateUrl: 'servicetype.component.html'
})
export class ServicetypeComponent {

  constructor() { }

}
