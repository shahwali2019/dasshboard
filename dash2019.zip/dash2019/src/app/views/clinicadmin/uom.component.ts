import { Component } from '@angular/core';

@Component({
  templateUrl: 'uom.component.html'
})
export class UomComponent {


  constructor() {

  }


}
