import { Component } from '@angular/core';

@Component({
  templateUrl: 'accountsreceivable.component.html'
})
export class AccountsreceivableComponent {

  constructor() { }


}
