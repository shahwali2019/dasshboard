import { Component } from '@angular/core';

@Component({
  templateUrl: 'assetmanagement.component.html'
})
export class AssetmanagementComponent {

  constructor() { }

}
