import { Component } from '@angular/core';

@Component({
  templateUrl: 'financialdashboard.component.html'
})
export class FinancialdashboardComponent {


  constructor() {

  }


}
