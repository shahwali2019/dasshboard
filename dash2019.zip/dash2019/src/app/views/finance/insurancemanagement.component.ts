import { Component } from '@angular/core';

@Component({
  templateUrl: 'insurancemanagement.component.html'
})
export class InsurancemanagementComponent {

  constructor() { }

}
