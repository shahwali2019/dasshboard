import { Component } from '@angular/core';

@Component({
  templateUrl: 'ledgers.component.html'
})
export class LedgersComponent {

  constructor() { }




}
