import {Component, SecurityContext} from '@angular/core';


@Component({
  templateUrl: 'materialmanagement.component.html'
})
export class MaterialmanagementComponent {

  constructor( ) {
   
  }

}
