import { Component } from '@angular/core';

@Component({
  templateUrl: 'role.component.html'
})
export class RoleComponent {

  constructor() { }


}
