import {Component, SecurityContext} from '@angular/core';

@Component({
  templateUrl: 'status.component.html'
})
export class StatusComponent {

  constructor() {
  }

 
}
