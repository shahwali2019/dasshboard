import { Component } from '@angular/core';

@Component({
  templateUrl: 'users.component.html'
})
export class UsersComponent {


  constructor() {

  }


}
