import { Component } from '@angular/core';

@Component({
  templateUrl: 'laboratoryanalysis.component.html'
})
export class LaboratoryanalysisComponent {

  constructor() { }

}
