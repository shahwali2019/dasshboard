import { Component } from '@angular/core';

@Component({
  templateUrl: 'labstockinventory.component.html'
})
export class LabstockinventoryComponent {

  constructor() { }




}
