import { Component } from '@angular/core';

@Component({
  templateUrl: 'masterlist.component.html'
})
export class MasterlistComponent {


  constructor() {

  }


}
