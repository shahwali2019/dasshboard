import { Component } from '@angular/core';

@Component({
  templateUrl: 'reagentlibrary.component.html'
})
export class ReagentlibraryComponent {


  constructor() {

  }


}
