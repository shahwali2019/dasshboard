import { Component } from '@angular/core';

@Component({
  templateUrl: 'city.component.html'
})
export class CityComponent {


  constructor() {

  }


}
