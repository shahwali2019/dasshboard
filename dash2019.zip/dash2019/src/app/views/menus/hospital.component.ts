import { Component } from '@angular/core';

@Component({
  templateUrl: 'hospital.component.html'
})
export class HospitalComponent {

  constructor() { }


}
