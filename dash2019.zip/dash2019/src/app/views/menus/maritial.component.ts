import { Component } from '@angular/core';

@Component({
  templateUrl: 'maritial.component.html'
})
export class MaritialComponent {

  constructor() { }

}
