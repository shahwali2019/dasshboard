import {Component, SecurityContext} from '@angular/core';


@Component({
  templateUrl: 'popovers.component.html'
})
export class PopoversComponent {

  constructor( ) {
   
  }

}
