import { Component } from '@angular/core';

@Component({
  templateUrl: 'religion.component.html'
})
export class ReligionComponent {

  constructor() { }

}
