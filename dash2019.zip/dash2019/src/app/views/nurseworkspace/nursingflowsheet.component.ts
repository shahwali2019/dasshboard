import { Component } from '@angular/core';

@Component({
  templateUrl: 'nursingflowsheet.component.html'
})
export class NursingflowsheetComponent {

  constructor() { }




}
