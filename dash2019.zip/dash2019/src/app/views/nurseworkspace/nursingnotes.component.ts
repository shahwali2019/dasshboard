import { Component } from '@angular/core';

@Component({
  templateUrl: 'nursingnotes.component.html'
})
export class NursingnotesComponent {


  constructor() {

  }


}
