import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: 'requisition.component.html'
})
export class RequisitionComponent implements OnInit {
  constructor() { }
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  ngOnInit() {
 
  }




}
