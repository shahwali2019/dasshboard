import { Component } from '@angular/core';

@Component({
  templateUrl: 'druglibrary.component.html'
})
export class DruglibraryComponent {

  constructor() { }

}
