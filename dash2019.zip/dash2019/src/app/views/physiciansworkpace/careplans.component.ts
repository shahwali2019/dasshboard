import { Component } from '@angular/core';

@Component({
  templateUrl: 'careplans.component.html'
})
export class CareplansComponent {

  constructor() {

  }


}


