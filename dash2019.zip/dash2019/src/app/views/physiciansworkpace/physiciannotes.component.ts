import { Component } from '@angular/core';

@Component({
  templateUrl: 'physiciannotes.component.html'
})
export class PhysiciannotesComponent {

  constructor() { }

}



