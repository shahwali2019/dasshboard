import { Worklist } from './worklist';

export const WORKLISTS: Worklist[] = [
  { pname: 'ANDY PATIENT', md: 'DR001', date: '18/07/2091', time: '08:00:00', activity: 'Conslut Appts', duration: 20, location: 'Consultation Room1', staff: '', status: 'Cl-Close', comment: '' },
  { pname: 'ANDY PATIENT', md: 'DR002', date: '18/07/2091', time: '1:00:00', activity: 'Conslut Appts', duration: 20, location: 'Consultation Room1', staff: '', status: 'S-Scheduled', comment: '' },
  { pname: 'ANDY PATIENT', md: 'DR003', date: '18/07/2091', time: '12:00:00', activity: 'Conslut Appts', duration: 20, location: 'Outpaatient Cons-1', staff: '', status: 'S-Scheduled', comment: '' },
  { pname: 'ANDY PATIENT', md: 'DR004', date: '18/07/2091', time: '11:00:00', activity: 'Conslut Appts', duration: 20, location: 'Outpaatient Cons-1', staff: '', status: 'S-Scheduled', comment: '' },
  { pname: 'ANDY PATIENT', md: 'DR005', date: '18/07/2091', time: '10:00:00', activity: 'Conslut Appts', duration: 20, location: 'Consultation Room1', staff: '', status: 'S-Scheduled', comment: '' }


];


