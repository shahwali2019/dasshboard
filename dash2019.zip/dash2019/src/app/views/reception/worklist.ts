export class Worklist {
  pname: string;
  md: string;
  date: string;
  time: string;
  activity: string;
  duration: number;
  location: string;
  staff: string;
  status: string;
  comment: string;

}



