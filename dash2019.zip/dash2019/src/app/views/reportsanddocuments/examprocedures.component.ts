import { Component } from '@angular/core';

@Component({
  templateUrl: 'examprocedures.component.html'
})
export class ExamproceduresComponent {

  constructor() { }

}



