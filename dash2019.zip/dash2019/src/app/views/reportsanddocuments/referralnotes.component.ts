import { Component } from '@angular/core';

@Component({
  templateUrl: 'referralnotes.component.html'
})
export class ReferralnotesComponent {

  constructor() {

  }


}


