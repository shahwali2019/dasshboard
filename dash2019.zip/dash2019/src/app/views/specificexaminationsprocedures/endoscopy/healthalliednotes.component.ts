import { Component } from '@angular/core';

@Component({
  templateUrl: 'healthalliednotes.component.html'
})
export class HealthalliednotesComponent {

  constructor() { }

}
