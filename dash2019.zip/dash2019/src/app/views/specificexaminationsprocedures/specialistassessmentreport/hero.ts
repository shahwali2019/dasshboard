export class Hero {
  status: string;
  id: number;
  name: string;
  sex: string;
  age: number;
  date: string;
  modality: string;
  study: string;
  accession: string;
}
