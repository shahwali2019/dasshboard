import { Component } from '@angular/core';

@Component({
  templateUrl: 'widgets.component.html'
})
export class WidgetsComponent {

  constructor() {

  }


}
